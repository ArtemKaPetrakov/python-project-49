### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArtemKaPetrakov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ArtemKaPetrakov/python-project-49/actions)

### CodeClimate:
[![Maintainability](https://api.codeclimate.com/v1/badges/bd506821e17ac53e9752/maintainability)](https://codeclimate.com/github/ArtemKaPetrakov/python-project-49/maintainability)