### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArtemKaPetrakov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ArtemKaPetrakov/python-project-49/actions)

### CodeClimate:
[![Maintainability](https://api.codeclimate.com/v1/badges/bd506821e17ac53e9752/maintainability)](https://codeclimate.com/github/ArtemKaPetrakov/python-project-49/maintainability)

### Asciinema brain-even
[![asciicast](https://asciinema.org/a/YRO5U5RIv9wNCzGhnC0Okckm5.svg)](https://asciinema.org/a/YRO5U5RIv9wNCzGhnC0Okckm5?t=5)