import random


def run_game():
    rule = 'What number is missing in the progression?'
    progresion_length = 10
    random_element = int(random.randrange(0, 9))
    progresion_increment = int(random.randrange(1, 10))
    star_number = int(random.randrange(1, 50))
    result = []
    count = 0

    while count < progresion_length:
        result.append(str(star_number))
        star_number += progresion_increment
        count += 1
    correct_answer = str(result[random_element])
    result[random_element] = '..'
    result = ' '.join(result)
    question = f'Question: {result}'

    return (question, correct_answer, rule)
