from brain_games.game_engine import game_run
from brain_games.games import progression


def main():
    # even_game()
    game_run(progression)


if __name__ == '__main__':
    main()
